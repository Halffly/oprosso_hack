	$('.menu-btn').on('click', function(e) {
	e.preventDefault();
	$(this).toggleClass('menu-btn_active');
	$('#menu').toggleClass('menu-nav');
	$('#menu').toggleClass('menu-nav_activate');
	$('#menu').toggleClass('flex');
	$('#menu').toggleClass('none');
	$('#reg_nav_mobile').toggleClass('none');
});
$(document).ready(function(){
	$('.block_corusel').slick({
		arrows:false,
		dots:false,
		slidesToShow:5,
		slidesToScroll:1,
		speed:20000,
		autoplay:true,
		autoplaySpeed:0,
		touchThreshold:1,
		waitForAnimate:true,
		 responsive: [
	    
	    {
	      breakpoint: 1271,
	      settings: {
	        slidesToShow: 4,
	        slidesToScroll: 2,
	        speed:4000,
	        autoplaySpeed:3000,
	      }
	    },
	    {
	      breakpoint: 1034,
	      settings: {
	        slidesToShow: 3,
	        slidesToScroll: 1,
	        speed:4000,
	        autoplaySpeed:3000,
	      }
	    },
	    {
	      breakpoint: 794,
	      settings: {
	        slidesToShow: 2,
	        slidesToScroll: 1,
	        speed:4000,
	        autoplaySpeed:3000,
	      }
	    },

		]
	});
});
$(document).scroll(function(){
	if ($(document).width()>680) {
		if ($(document).scrollTop())
			$('nav').addClass('fixed_navbar');
		else 
			$('nav').removeClass('fixed_navbar');
	}
});
$(function(){
	if ($(document).width()<805) {
		$(".blockstat").removeClass("flex")
	}
	else {
		$(".blockstat").addClass("flex")
	}
});