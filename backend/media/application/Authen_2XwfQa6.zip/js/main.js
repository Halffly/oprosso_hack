window.onload = function() {
    let pred = document.getElementById('preloader')
    $(pred).remove()
    $(function(){
        $(".up").hide();

        $(window).scroll(function(){
            if ($(this).scrollTop() > 200){
                $(".up").fadeIn();
            }
            else {
                $(".up").fadeOut();
            }
        });
        $(".butup").on("click", function(q){
            q.preventDefault();
            $("body, html").animate({
                scrollTop:0
            }, 800);
            return false;
        });
   });
}
$(function(){
    if ($(document).width() < 450){
        $(".butup").remove()
    }
});